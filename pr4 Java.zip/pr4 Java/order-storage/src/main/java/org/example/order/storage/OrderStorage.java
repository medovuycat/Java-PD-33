package org.example.order.storage;

import org.example.order.processing.Product;

import java.util.ArrayList;
import java.util.List;

public class OrderStorage<T extends Product> {
    private List<T> orders = new ArrayList<>();

    public void saveOrder(T product) {
        orders.add(product);
        System.out.println("Order saved: " + product.getName() + " - " + product.getPrice());
    }

    public void printAllOrders() {
        System.out.println("All saved orders:");
        for (T product : orders) {
            System.out.println("Product: " + product.getName() + ", Price: " + product.getPrice() + ", Description: " + product.getDescription());
        }
    }
}
