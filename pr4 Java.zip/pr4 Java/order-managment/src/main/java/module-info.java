module order.managment {
    requires order.processing;
    requires order.storage;
    requires java.base;
    requires javafaker;
    requires java.sql;
}