package org.example.order.processing;

import lombok.Getter;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class OrderProcessor<T extends Product> {
    @Getter
    private T product;
    private ExecutorService executorService;

    public OrderProcessor(T product) {
        this.product = product;
        this.executorService = Executors.newSingleThreadExecutor();
    }

    public void process() {
        try {
            System.out.println("Processing order for: " + product.getName() + " " + product.getPrice() + " " + product.getDescription());
            if (product.getPrice() < 0) {
                throw new IllegalArgumentException("Price cannot be negative");
            }
        } catch (Exception e) {
            System.err.println("Failed to process order: " + e.getMessage());
        }
    }

    public void startProcessing() {
        Runnable task = () -> {
            System.out.println("Processing product in thread: " + Thread.currentThread().getName());
            process();
        };

        Future<?> future = executorService.submit(task);

        try {
            future.get();
        } catch (InterruptedException e) {
            System.err.println("Thread was interrupted: " + e.getMessage());
            Thread.currentThread().interrupt();
        } catch (ExecutionException e) {
            System.err.println("Error during async processing: " + e.getCause().getMessage());
        }
    }

    public void shutdown() {
        executorService.shutdown();
    }
}
