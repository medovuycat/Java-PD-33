package org.example.order.managment;

import com.github.javafaker.Faker;
import org.example.order.processing.Clothing;
import org.example.order.processing.Electronics;
import org.example.order.processing.OrderProcessor;
import org.example.order.processing.Product;
import org.example.order.storage.OrderStorage;

public class Main {
    public static void main(String[] args) {
        OrderStorage<Product> orderStorage = new OrderStorage<>();

        var faker = new Faker();

        var clothing = Clothing.builder()
                .name(faker.commerce().productName())
                .price(Double.parseDouble(faker.commerce().price().replace(",",".")))
                .description(faker.beer().name())
                .build();
        var electronics = Electronics.builder()
                .name(faker.commerce().productName())
                .price(Double.parseDouble(faker.commerce().price().replace(",",".")))
                .description(faker.beer().name())
                .build();
//        var electronics = Electronics.builder()
//                .name("Mobile phone")
//                .price(500.00)
//                .description("Xiaomi")
//                .build();
//        var clothing = Clothing.builder()
//                .name("Trousers")
//                .price(200.00)
//                .description("Blue")
//                .build();
//
//        OrderProcessor<Electronics> electronicsOrder = new OrderProcessor<>(new Electronics("Mobile phone", 5000.00, "Xiaomi"));
//        OrderProcessor<Clothing> clothingOrder = new OrderProcessor<>(new Clothing("Trousers", 200.00, "Blue"));
        OrderProcessor<Electronics> electronicsOrder = new OrderProcessor<>(electronics);
        OrderProcessor<Clothing> clothingOrder = new OrderProcessor<>(clothing);

        electronicsOrder.process();
        clothingOrder.process();

        orderStorage.saveOrder(electronicsOrder.getProduct());
        orderStorage.saveOrder(clothingOrder.getProduct());

        orderStorage.printAllOrders();

        electronicsOrder.startProcessing();
        clothingOrder.startProcessing();

        electronicsOrder.shutdown();
        clothingOrder.shutdown();
    }
}