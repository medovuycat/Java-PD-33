module order.storage {
    requires order.processing;
    requires static lombok;
    exports org.example.order.storage;
}