package org.example;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestRecognizerTest {

    @ParameterizedTest
    @CsvSource({
            "'abcTESTabc', F",
            "'abcTES', 3",
            "'TESTTEST', F",
            "'T', 1",
            "'TE', 2",
            "'', 0",
    })
    public void testRecognize(String input, String expected) {
        TestRecognizer recognizer = new TestRecognizer();
        String result = recognizer.recognize(input);
        assertEquals(expected, result);
    }
}
