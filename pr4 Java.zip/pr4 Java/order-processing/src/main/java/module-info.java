module order.processing {
    requires static lombok;
    exports org.example.order.processing;
}