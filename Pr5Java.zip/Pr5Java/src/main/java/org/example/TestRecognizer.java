package org.example;

public class TestRecognizer {
    public String recognize(String input) {
        int test = 0;
        char[] chars = input.toCharArray();

        for (char c : chars) {
            switch (test) {
                case 0:
                    test = (c == 'T') ? 1 : 0;
                    break;
                case 1:
                    test = (c == 'E') ? 2 : (c == 'T' ? 1 : 0);
                    break;
                case 2:
                    test = (c == 'S') ? 3 : (c == 'T' ? 1 : 0);
                    break;
                case 3:
                    test = (c == 'T') ? 4 : (c == 'T' ? 1 : 0);
                    break;
                case 4:
                    return "F";
            }
        }
        return Integer.toString(test);
    }
}
